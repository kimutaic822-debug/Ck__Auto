package com.ckauto.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class KeepAliveService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    private var wl: PowerManager.WakeLock? = null

    override fun onDestroy() {
        try {
            wl?.release()
        } catch (e: Exception) {
        }
        wl = null
        stopForeground(true)
        super.onDestroy()
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val ch = "ck_auto"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "CK Auto", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, ch)
            .setContentTitle("CK Auto is running")
            .setContentText("Automation ON \u2022 Sync active \u2022 Monitoring messages")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Automation is ON\nSync is active\nMonitoring payments and messages"))
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(pi)
            .setOngoing(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (wl == null) {
            try {
                wl = getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ckauto:keep")
                wl?.setReferenceCounted(false)
                wl?.acquire()
            } catch (e: Exception) {
            }
        }
        return START_STICKY
    }
}
